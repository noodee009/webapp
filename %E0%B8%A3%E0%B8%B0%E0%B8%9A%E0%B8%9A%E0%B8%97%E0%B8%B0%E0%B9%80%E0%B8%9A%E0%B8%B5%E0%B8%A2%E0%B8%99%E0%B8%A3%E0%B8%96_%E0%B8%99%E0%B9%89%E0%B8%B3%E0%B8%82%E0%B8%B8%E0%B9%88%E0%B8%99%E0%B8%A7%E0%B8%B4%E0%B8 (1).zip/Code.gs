/*****************************************************************
 * ระบบทะเบียนรถจักรยานยนต์นักเรียน - โรงเรียนน้ำขุ่นวิทยา
 * ไฟล์ : Code.gs
 *****************************************************************/

const CONFIG = {
  SPREADSHEET_ID: '1tjkXcm5zfff0eW9dMawtT16HUx8yYDLBbH0mA9A9dAU',
  SCHOOL_NAME: 'โรงเรียนน้ำขุ่นวิทยา',
  SUB_TITLE: ['สังกัดองค์การบริหารส่วนจังหวัดอุบลราชธานี', 'กลุ่มบริหารกิจการนักเรียน', 'งานจราจร'],
  LOGO_URL: '',                                  // ตั้งค่าโลโก้ได้จากเมนูผู้ดูแลระบบ
  REG_PREFIX: 'NKW',                          // รูปแบบเลขทะเบียน NKW-2569-0001
  DEFAULT_PROVINCE: 'อุบลราชธานี',
  
  /* ตั้งค่าโฟลเดอร์เก็บรูปใน Google Drive */
  UPLOAD_FOLDER_ID: '1JKim7tElA6zPVvfqtYboX0OxCwrHwC9L', // โฟลเดอร์ Google Drive สำหรับรูปภาพ
  UPLOAD_FOLDER: 'ระบบทะเบียนรถ_โรงเรียนน้ำขุ่นวิทยา',
  USE_SUB_FOLDERS: true,                      // true = แยกโฟลเดอร์ย่อย "รูปนักเรียน" และ "รูปรถ" อัตโนมัติ

  DEFAULT_ADMIN: { username: 'admin', password: 'admin212224', fullName: 'ผู้ดูแลระบบหลัก' },
  SALT: 'CHANGE-ME-SECRET-2569',              // เปลี่ยนก่อนใช้งานจริง (ห้ามเปลี่ยนหลังมีผู้ใช้แล้ว)
  SESSION_SECONDS: 21600,                     // 6 ชั่วโมง (สูงสุดของ CacheService)
  MAX_GRADE: 6,
  MAX_ROOM: 12
};

const TZ = 'Asia/Bangkok';
const ST = { ACTIVE: 'ใช้งานอยู่', PENDING: 'รออนุมัติ', REJECT: 'ไม่อนุมัติ', SUSPEND: 'ระงับใช้งาน' };

const T = {
  STU: { name: '1. ข้อมูลนักเรียน', cols: [
    ['id','รหัสระบบ'],['studentId','รหัสนักเรียน'],['fullName','ชื่อ-สกุล'],['classLevel','ระดับชั้น'],
    ['phone','เบอร์โทรศัพท์'],['username','Username'],['passwordHash','Password (เข้ารหัส)'],
    ['photoUrl','รูปถ่าย'],['status','สถานะ'],['createdAt','วันที่สมัคร']] },
  ADM: { name: '2. ผู้ดูแลระบบ', cols: [
    ['id','รหัสระบบ'],['fullName','ชื่อ-สกุล'],['username','Username'],['passwordHash','Password (เข้ารหัส)'],
    ['phone','เบอร์โทรศัพท์'],['reason','เหตุผลการสมัคร'],['role','บทบาท'],['status','สถานะ'],['createdAt','วันที่สมัคร']] },
  VEH: { name: '3. ข้อมูลรถ', cols: [
    ['id','รหัสระบบ'],['regNo','เลขทะเบียนระบบ'],['studentId','รหัสนักเรียน'],['studentName','ชื่อนักเรียน'],
    ['classLevel','ระดับชั้น'],['studentPhone','เบอร์นักเรียน'],['brand','ยี่ห้อ'],['model','รุ่น'],['color','สี'],
    ['plate','หมายเลขทะเบียน'],['province','จังหวัด'],['ownerName','ชื่อเจ้าของรถ'],['ownerPhone','เบอร์เจ้าของรถ'],
    ['relation','ความสัมพันธ์'],['ownerAddress','ที่อยู่'],['photoUrl','รูปรถ'],['status','สถานะ'],['note','หมายเหตุ'],
    ['createdAt','วันที่ยื่น'],['updatedAt','แก้ไขล่าสุด'],['approvedAt','วันที่อนุมัติ'],['approvedBy','ผู้อนุมัติ']] },
  VIO: { name: '4. การกระทำผิด', cols: [
    ['id','รหัสระบบ'],['vehicleId','รหัสรถ'],['regNo','เลขทะเบียนระบบ'],['plate','ทะเบียนรถ'],['studentId','รหัสนักเรียน'],
    ['studentName','ชื่อนักเรียน'],['classLevel','ระดับชั้น'],['date','วันที่เกิดเหตุ'],['type','ประเภทการกระทำผิด'],
    ['detail','รายละเอียด'],['notifyParent','แจ้งผู้ปกครอง'],['recordedBy','ผู้บันทึก'],['createdAt','วันที่บันทึก']] },
  LOG: { name: '5. บันทึกการใช้งาน', cols: [
    ['time','เวลา'],['user','ผู้ใช้'],['role','บทบาท'],['action','การกระทำ'],['detail','รายละเอียด']] }
};

/* ========================= WEB APP ========================= */
function doGet(e) {
  ensureSetup_();
  const p = (e && e.parameter) || {};
  if (p.verify) {
    return HtmlService.createHtmlOutput(renderVerify_(p.verify))
      .setTitle('ตรวจสอบทะเบียนรถ - ' + CONFIG.SCHOOL_NAME)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  const t = HtmlService.createTemplateFromFile('Index');
  const branding = getBranding_();
  t.cfg = JSON.stringify({
    schoolName: CONFIG.SCHOOL_NAME, subTitle: CONFIG.SUB_TITLE,
    logoUrl: branding.logoUrl, backgroundUrl: branding.backgroundUrl,
    defaultProvince: CONFIG.DEFAULT_PROVINCE, maxGrade: CONFIG.MAX_GRADE, maxRoom: CONFIG.MAX_ROOM,
    webAppUrl: ScriptApp.getService().getUrl()
  });
  return t.evaluate()
    .setTitle('ระบบทะเบียนรถจักรยานยนต์นักเรียน')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** จุดเรียก API เดียวจากหน้าเว็บ */
function api(action, p) {
  try {
    if (!Object.prototype.hasOwnProperty.call(ROUTES, action)) throw new Error('ไม่พบคำสั่งที่ร้องขอ');
    const data = ROUTES[action](p || {});
    return { ok: true, data: data === undefined ? true : data };
  } catch (err) {
    return { ok: false, msg: err.message };
  }
}

/* ========================= SETUP ========================= */
function ensureSetup_() {
  if (!PropertiesService.getScriptProperties().getProperty('SETUP_V2')) setup();
}

/** รันฟังก์ชันนี้ 1 ครั้งก่อน Deploy */
function setup() {
  Object.keys(T).forEach(k => sheet_(T[k]));
  const admins = readAll_(T.ADM);
  const du = CONFIG.DEFAULT_ADMIN;
  if (!admins.some(a => a.username.toLowerCase() === du.username.toLowerCase())) {
    insert_(T.ADM, { id: uid_(), fullName: du.fullName, username: du.username, passwordHash: hash_(du.password),
      phone: '', reason: 'บัญชีเริ่มต้นของระบบ', role: 'superadmin', status: ST.ACTIVE, createdAt: now_() });
  }
  // ตรวจสอบโฟลเดอร์ Drive เมื่อมีการอัปโหลดจริง เพื่อไม่ให้หน้าเว็บล่มหากสิทธิ์ Drive ยังไม่พร้อม
  const ss = ss_();
  ['Sheet1', 'ชีต1', 'แผ่นงาน1'].forEach(n => {
    const sh = ss.getSheetByName(n);
    if (sh && ss.getSheets().length > 1 && sh.getLastRow() === 0) ss.deleteSheet(sh);
  });
  PropertiesService.getScriptProperties().setProperty('SETUP_V2', '1');
  return 'ติดตั้งระบบเรียบร้อย';
}

/* ========================= ROUTES ========================= */
const ROUTES = {
  /* ---------- ทั่วไป ---------- */
  me(p) {
    const raw = p.token && CacheService.getScriptCache().get('S_' + p.token);
    return raw ? JSON.parse(raw) : null;
  },
  logout(p) {
    if (p.token) CacheService.getScriptCache().remove('S_' + p.token);
    return true;
  },
  changePassword(p) {
    const s = sess_(p);
    req_(p, ['oldPassword', 'newPassword']);
    checkPass_(p.newPassword);
    const t = s.role === 'student' ? T.STU : T.ADM;
    return lock_(() => {
      const u = find_(t, 'id', s.id);
      if (!u || u.passwordHash !== hash_(p.oldPassword)) throw new Error('รหัสผ่านเดิมไม่ถูกต้อง');
      update_(t, u._row, { passwordHash: hash_(p.newPassword) });
      log_(s.username, s.role, 'เปลี่ยนรหัสผ่าน');
      return true;
    });
  },

  /* ---------- ลงทะเบียนนักเรียนแบบสาธารณะ (ไม่ต้อง Login) ---------- */
  publicRegister(p) {
    req_(p, ['studentId', 'fullName', 'classLevel', 'phone', 'brand', 'model', 'color',
      'plate', 'province', 'ownerName', 'ownerPhone', 'relation']);
    if (!p.accept) throw new Error('กรุณายืนยันความถูกต้องและยอมรับเงื่อนไขการใช้งาน');
    const sid = String(p.studentId).trim();
    if (sid.length < 2 || sid.length > 30) throw new Error('รหัสนักเรียนไม่ถูกต้อง');
    checkClassLevel_(p.classLevel);
    checkPhone_(p.phone);
    checkPhone_(p.ownerPhone);
    if (!p.vehiclePhoto) throw new Error('กรุณาแนบรูปถ่ายรถจักรยานยนต์');

    return lock_(() => {
      const student = find_(T.STU, 'studentId', sid);
      const current = stuVehicle_(sid);

      if (current && [ST.ACTIVE, ST.PENDING, ST.SUSPEND].indexOf(current.status) >= 0) {
        throw new Error('รหัสนักเรียนนี้มีข้อมูลลงทะเบียนอยู่แล้ว กรุณาตรวจสอบสถานะหรือติดต่อครูงานจราจร');
      }

      const plate = normPlate_(p.plate);
      const duplicatePlate = readAll_(T.VEH).find(v =>
        normPlate_(v.plate) === plate && v.province === p.province &&
        v.studentId !== sid && v.status !== ST.REJECT
      );
      if (duplicatePlate) throw new Error('ทะเบียนรถนี้มีผู้ลงทะเบียนไว้แล้ว');

      const studentPhoto = p.studentPhoto
        ? saveImage_(p.studentPhoto, 'STU_' + sid, 'รูปนักเรียน')
        : (student ? student.photoUrl : '');
      const vehiclePhoto = saveImage_(p.vehiclePhoto, 'VEH_' + plate, 'รูปรถ');

      const studentData = {
        studentId: sid,
        fullName: String(p.fullName).trim(),
        classLevel: p.classLevel,
        phone: digits_(p.phone),
        photoUrl: studentPhoto,
        status: ST.ACTIVE
      };

      if (student) {
        update_(T.STU, student._row, studentData);
      } else {
        insert_(T.STU, Object.assign({
          id: uid_(), username: '', passwordHash: '', createdAt: now_()
        }, studentData));
      }

      const vehicleData = {
        studentId: sid,
        studentName: String(p.fullName).trim(),
        classLevel: p.classLevel,
        studentPhone: digits_(p.phone),
        brand: p.brand,
        model: String(p.model).trim(),
        color: String(p.color).trim(),
        plate: String(p.plate).trim(),
        province: p.province,
        ownerName: String(p.ownerName).trim(),
        ownerPhone: digits_(p.ownerPhone),
        relation: p.relation,
        ownerAddress: p.ownerAddress || '',
        photoUrl: vehiclePhoto,
        status: ST.PENDING,
        note: '',
        updatedAt: now_()
      };

      if (current && current.status === ST.REJECT) {
        update_(T.VEH, current._row, vehicleData);
      } else {
        vehicleData.id = uid_();
        vehicleData.regNo = '';
        vehicleData.createdAt = now_();
        insert_(T.VEH, vehicleData);
      }

      log_(sid, 'public', 'ลงทะเบียนรถจักรยานยนต์', String(p.plate).trim());
      return {
        studentId: sid,
        fullName: String(p.fullName).trim(),
        plate: String(p.plate).trim(),
        province: p.province,
        status: ST.PENDING
      };
    });
  },

  publicStatus(p) {
    req_(p, ['studentId', 'phone']);
    checkPhone_(p.phone);
    const sid = String(p.studentId).trim();
    const student = find_(T.STU, 'studentId', sid);
    if (!student || digits_(student.phone) !== digits_(p.phone)) {
      throw new Error('ไม่พบข้อมูล กรุณาตรวจสอบรหัสนักเรียนและเบอร์โทรศัพท์');
    }
    const vehicle = stuVehicle_(sid);
    if (!vehicle) return { registered: false, studentName: student.fullName, classLevel: student.classLevel };
    return {
      registered: true,
      studentName: vehicle.studentName,
      classLevel: vehicle.classLevel,
      status: vehicle.status,
      regNo: vehicle.regNo || '',
      plate: vehicle.plate,
      province: vehicle.province,
      brand: vehicle.brand,
      model: vehicle.model,
      note: vehicle.note || '',
      submittedAt: vehicle.createdAt || vehicle.updatedAt || ''
    };
  },

  /* ---------- ผู้ดูแลระบบ ---------- */
  adminRegister(p) {
    req_(p, ['fullName', 'username', 'password', 'phone', 'reason']);
    checkUser_(p.username); checkPass_(p.password); checkPhone_(p.phone);
    return lock_(() => {
      if (usernameTaken_(p.username)) throw new Error('Username นี้ถูกใช้งานแล้ว');
      insert_(T.ADM, { id: uid_(), fullName: p.fullName, username: String(p.username).trim(),
        passwordHash: hash_(p.password), phone: digits_(p.phone), reason: p.reason,
        role: 'admin', status: ST.PENDING, createdAt: now_() });
      log_(p.username, 'admin', 'ส่งคำขอเป็นผู้ดูแล', p.fullName);
      return true;
    });
  },

  adminLogin(p) {
    req_(p, ['username', 'password']);
    const un = String(p.username).trim().toLowerCase();
    const a = readAll_(T.ADM).find(x => x.username.toLowerCase() === un);
    if (!a || a.passwordHash !== hash_(p.password)) throw new Error('Username หรือ Password ไม่ถูกต้อง');
    if (a.status === ST.PENDING) throw new Error('บัญชีของคุณอยู่ระหว่างรอการอนุมัติจากแอดมิน');
    if (a.status !== ST.ACTIVE) throw new Error('บัญชีของคุณไม่ได้รับอนุญาตให้ใช้งาน');
    const user = { role: 'admin', level: a.role, id: a.id, username: a.username, fullName: a.fullName };
    log_(a.username, 'admin', 'เข้าสู่ระบบ');
    return { token: newSession_(user), user };
  },

  getSettings(p) {
    sess_(p, 'admin');
    return getBranding_();
  },

  saveBranding(p) {
    const s = sess_(p, 'admin');
    const props = PropertiesService.getScriptProperties();
    if (p.logo) {
      const logoUrl = saveImage_(p.logo, 'SCHOOL_LOGO', 'โลโก้และพื้นหลัง');
      props.setProperty('BRAND_LOGO_URL', logoUrl);
    }
    if (p.background) {
      const backgroundUrl = saveImage_(p.background, 'SCHOOL_BACKGROUND', 'โลโก้และพื้นหลัง');
      props.setProperty('BRAND_BG_URL', backgroundUrl);
    }
    log_(s.username, 'admin', 'ปรับแต่งโลโก้และภาพพื้นหลัง');
    return getBranding_();
  },

  adminDashboard(p) {
    sess_(p, 'admin');
    const veh = readAll_(T.VEH), vio = readAll_(T.VIO), adm = readAll_(T.ADM);
    return {
      stats: {
        active: veh.filter(v => v.status === ST.ACTIVE).length,
        pending: veh.filter(v => v.status === ST.PENDING).length,
        violations: vio.length,
        pendingAdmins: adm.filter(a => a.status === ST.PENDING).length
      },
      recentPending: veh.filter(v => v.status === ST.PENDING).slice(-5).reverse().map(strip_),
      recentVio: vio.slice(-5).reverse().map(strip_),
      sheetUrl: ss_().getUrl()
    };
  },

  listVehicles(p) {
    sess_(p, 'admin');
    const cnt = {};
    readAll_(T.VIO).forEach(x => cnt[x.vehicleId] = (cnt[x.vehicleId] || 0) + 1);
    return readAll_(T.VEH)
      .filter(v => !p.status || p.status === 'all' || v.status === p.status)
      .reverse()
      .map(v => Object.assign(strip_(v), { vioCount: cnt[v.id] || 0 }));
  },

  setVehicleStatus(p) {
    const s = sess_(p, 'admin');
    if ([ST.ACTIVE, ST.REJECT, ST.SUSPEND, ST.PENDING].indexOf(p.status) < 0) throw new Error('สถานะไม่ถูกต้อง');
    return lock_(() => {
      const v = find_(T.VEH, 'id', p.id);
      if (!v) throw new Error('ไม่พบข้อมูลรถ');
      const data = { status: p.status, note: p.note || '', updatedAt: now_() };
      if (p.status === ST.ACTIVE) {
        if (!v.regNo) data.regNo = genRegNo_();
        data.approvedAt = now_();
        data.approvedBy = s.fullName;
      }
      update_(T.VEH, v._row, data);
      log_(s.username, 'admin', 'เปลี่ยนสถานะรถเป็น ' + p.status, v.plate + ' ' + v.province);
      return data.regNo || v.regNo || true;
    });
  },

  updateVehicle(p) {
    const s = sess_(p, 'admin');
    const allow = ['brand', 'model', 'color', 'plate', 'province', 'ownerName', 'ownerPhone', 'relation', 'ownerAddress', 'note'];
    return lock_(() => {
      const v = find_(T.VEH, 'id', p.id);
      if (!v) throw new Error('ไม่พบข้อมูลรถ');
      const data = { updatedAt: now_() };
      allow.forEach(k => {
        if (p.data && p.data[k] !== undefined) data[k] = k === 'ownerPhone' ? digits_(p.data[k]) : p.data[k];
      });
      update_(T.VEH, v._row, data);
      log_(s.username, 'admin', 'แก้ไขข้อมูลรถ', v.plate);
      return true;
    });
  },

  deleteVehicle(p) {
    const s = sess_(p, 'admin');
    return lock_(() => {
      const v = find_(T.VEH, 'id', p.id);
      if (!v) throw new Error('ไม่พบข้อมูลรถ');
      sheet_(T.VEH).deleteRow(v._row); invalidateTableCache_(T.VEH);
      log_(s.username, 'admin', 'ลบข้อมูลรถ', v.plate + ' ' + v.studentName);
      return true;
    });
  },

  addViolation(p) {
    const s = sess_(p, 'admin');
    req_(p, ['vehicleId', 'date', 'type']);
    return lock_(() => {
      const v = find_(T.VEH, 'id', p.vehicleId);
      if (!v) throw new Error('ไม่พบข้อมูลรถ');
      insert_(T.VIO, { id: uid_(), vehicleId: v.id, regNo: v.regNo, plate: v.plate + ' ' + v.province,
        studentId: v.studentId, studentName: v.studentName, classLevel: v.classLevel,
        date: p.date, type: p.type, detail: p.detail || '', notifyParent: p.notify ? 'ใช่' : 'ไม่',
        recordedBy: s.fullName, createdAt: now_() });
      log_(s.username, 'admin', 'บันทึกการกระทำผิด', v.plate + ' : ' + p.type);
      return true;
    });
  },

  listViolations(p) {
    sess_(p, 'admin');
    return readAll_(T.VIO).reverse().map(strip_);
  },

  deleteViolation(p) {
    const s = sess_(p, 'admin');
    return lock_(() => {
      const x = find_(T.VIO, 'id', p.id);
      if (!x) throw new Error('ไม่พบรายการ');
      sheet_(T.VIO).deleteRow(x._row); invalidateTableCache_(T.VIO);
      log_(s.username, 'admin', 'ลบบันทึกการกระทำผิด', x.plate + ' : ' + x.type);
      return true;
    });
  },

  listUsers(p) {
    const s = sess_(p, 'admin');
    return { students: readAll_(T.STU).reverse().map(strip_), admins: readAll_(T.ADM).reverse().map(strip_), me: s.id };
  },

  setStudentStatus(p) {
    const s = sess_(p, 'admin');
    if ([ST.ACTIVE, ST.SUSPEND].indexOf(p.status) < 0) throw new Error('สถานะไม่ถูกต้อง');
    return lock_(() => {
      const u = find_(T.STU, 'id', p.id);
      if (!u) throw new Error('ไม่พบนักเรียน');
      update_(T.STU, u._row, { status: p.status });
      log_(s.username, 'admin', 'เปลี่ยนสถานะนักเรียนเป็น ' + p.status, u.studentId);
      return true;
    });
  },

  resetStudentPassword(p) {
    const s = sess_(p, 'admin');
    return lock_(() => {
      const u = find_(T.STU, 'id', p.id);
      if (!u) throw new Error('ไม่พบนักเรียน');
      update_(T.STU, u._row, { passwordHash: hash_(u.studentId) });
      log_(s.username, 'admin', 'รีเซ็ตรหัสผ่านนักเรียน', u.studentId);
      return u.studentId;
    });
  },

  /** คำสั่ง resetPassword: รีเซ็ตรหัสผ่านบัญชีผู้ดูแลโดย Super Admin เท่านั้น */
  resetPassword(p) {
    const s = sess_(p, 'admin');
    if (s.level !== 'superadmin') throw new Error('เฉพาะผู้ดูแลระบบหลักเท่านั้นที่รีเซ็ตรหัสผ่านผู้ดูแลคนอื่นได้');
    req_(p, ['id']);
    return lock_(() => {
      const a = find_(T.ADM, 'id', p.id);
      if (!a) throw new Error('ไม่พบบัญชีผู้ดูแลระบบ');
      if (a.id === s.id) throw new Error('ไม่สามารถรีเซ็ตรหัสผ่านบัญชีที่กำลังใช้งานได้ กรุณาใช้เมนูรหัสผ่านของฉัน');

      // สร้างรหัสผ่านชั่วคราวแบบสุ่ม และส่งกลับให้แสดงเพียงครั้งเดียว
      const temporaryPassword = Utilities.getUuid().replace(/-/g, '').slice(0, 12) + 'A9!';
      update_(T.ADM, a._row, { passwordHash: hash_(temporaryPassword) });
      log_(s.username, 'admin', 'รีเซ็ตรหัสผ่านผู้ดูแลระบบ', a.username);
      return { username: a.username, fullName: a.fullName, temporaryPassword };
    });
  },

  // ชื่อเดิมคงไว้เพื่อรองรับหน้าเว็บเวอร์ชันก่อนหน้า
  resetAdminPassword(p) { return ROUTES.resetPassword(p); },

  setAdminStatus(p) {
    const s = sess_(p, 'admin');
    if ([ST.ACTIVE, ST.SUSPEND, ST.REJECT].indexOf(p.status) < 0) throw new Error('สถานะไม่ถูกต้อง');
    return lock_(() => {
      const a = find_(T.ADM, 'id', p.id);
      if (!a) throw new Error('ไม่พบผู้ใช้');
      if (a.id === s.id) throw new Error('ไม่สามารถเปลี่ยนสถานะบัญชีของตนเองได้');
      if (a.role === 'superadmin' && s.level !== 'superadmin') throw new Error('ไม่มีสิทธิ์แก้ไขผู้ดูแลระบบหลัก');
      update_(T.ADM, a._row, { status: p.status });
      log_(s.username, 'admin', 'เปลี่ยนสถานะผู้ดูแลเป็น ' + p.status, a.username);
      return true;
    });
  },

  report(p) {
    sess_(p, 'admin');
    const veh = readAll_(T.VEH), vio = readAll_(T.VIO), stu = readAll_(T.STU);
    const count = (arr, fn) => arr.reduce((m, x) => { const k = fn(x) || 'ไม่ระบุ'; m[k] = (m[k] || 0) + 1; return m; }, {});
    const active = veh.filter(v => v.status === ST.ACTIVE);
    const top = Object.entries(count(vio, v => [v.studentId, v.studentName, v.classLevel].join('|')))
      .sort((a, b) => b[1] - a[1]).slice(0, 10)
      .map(([k, n]) => { const [id, name, cls] = k.split('|'); return { studentId: id, name, classLevel: cls, count: n }; });
    return {
      totals: {
        students: stu.length, vehicles: veh.length, active: active.length,
        pending: veh.filter(v => v.status === ST.PENDING).length,
        violations: vio.length, notified: vio.filter(v => v.notifyParent === 'ใช่').length
      },
      byGrade: count(active, v => String(v.classLevel).split('/')[0]),
      byBrand: count(active, v => v.brand),
      byType: count(vio, v => v.type),
      byMonth: count(vio, v => String(v.date).slice(0, 7)),
      top
    };
  }
};

/* ========================= BRANDING ========================= */
function getBranding_() {
  const props = PropertiesService.getScriptProperties();
  return {
    logoUrl: props.getProperty('BRAND_LOGO_URL') || CONFIG.LOGO_URL || '',
    backgroundUrl: props.getProperty('BRAND_BG_URL') || ''
  };
}

function checkClassLevel_(value) {
  const allowed = /^ม\.[1-6]\/(?:[1-9]|1[0-2])$/;
  if (!allowed.test(String(value || '').trim())) throw new Error('กรุณาเลือกระดับชั้น/ห้องให้ถูกต้อง');
}

/* ========================= DATA HELPERS ========================= */
let _SS_INSTANCE = null;
const _SHEET_INSTANCES = {};

function ss_() {
  if (!_SS_INSTANCE) {
    _SS_INSTANCE = CONFIG.SPREADSHEET_ID
      ? SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID)
      : SpreadsheetApp.getActiveSpreadsheet();
  }
  return _SS_INSTANCE;
}

function sheet_(t) {
  if (_SHEET_INSTANCES[t.name]) return _SHEET_INSTANCES[t.name];
  const ss = ss_();
  let sh = ss.getSheetByName(t.name);
  if (!sh) {
    sh = ss.insertSheet(t.name);
    const n = t.cols.length;
    sh.getRange(1, 1, sh.getMaxRows(), n).setNumberFormat('@');
    sh.getRange(1, 1, 1, n).setValues([t.cols.map(c => c[1])])
      .setFontWeight('bold').setBackground('#0d47a1').setFontColor('#ffffff').setHorizontalAlignment('center');
    sh.setFrozenRows(1);
    sh.autoResizeColumns(1, n);
  }
  _SHEET_INSTANCES[t.name] = sh;
  return sh;
}

function readAll_(t) {
  const cache = CacheService.getScriptCache();
  const key = 'TAB_' + Utilities.base64EncodeWebSafe(t.name).slice(0, 40);
  const cached = cache.get(key);
  if (cached) {
    try { return JSON.parse(cached); } catch (e) { cache.remove(key); }
  }
  const sh = sheet_(t), last = sh.getLastRow();
  if (last < 2) return [];
  const rows = sh.getRange(2, 1, last - 1, t.cols.length).getDisplayValues()
    .map((r, i) => { const o = { _row: i + 2 }; t.cols.forEach((c, j) => o[c[0]] = String(r[j])); return o; })
    .filter(o => o.id || o.time);
  const packed = JSON.stringify(rows);
  // CacheService has a 100 KB per-key limit; skip large tables safely.
  if (packed.length < 90000) {
    try { cache.put(key, packed, 15); } catch (e) {}
  }
  return rows;
}

function invalidateTableCache_(t) {
  const key = 'TAB_' + Utilities.base64EncodeWebSafe(t.name).slice(0, 40);
  CacheService.getScriptCache().remove(key);
}

function insert_(t, obj) {
  const sh = sheet_(t), n = t.cols.length, row = sh.getLastRow() + 1;
  if (row > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), 200);
  sh.getRange(row, 1, 1, n).setNumberFormat('@').setValues([t.cols.map(c => safe_(obj[c[0]]))]);
  invalidateTableCache_(t);
}

function update_(t, row, obj) {
  const sh = sheet_(t), n = t.cols.length, rg = sh.getRange(row, 1, 1, n), cur = rg.getDisplayValues()[0];
  t.cols.forEach((c, j) => { if (obj[c[0]] !== undefined) cur[j] = safe_(obj[c[0]]); });
  rg.setNumberFormat('@').setValues([cur]);
  invalidateTableCache_(t);
}

function find_(t, key, val) {
  const v = String(val).trim();
  return readAll_(t).find(o => o[key] === v);
}

function stuVehicle_(studentId) {
  const list = readAll_(T.VEH).filter(v => v.studentId === String(studentId));
  return list.length ? list[list.length - 1] : null;
}

function genRegNo_() {
  const y = Number(Utilities.formatDate(new Date(), TZ, 'yyyy')) + 543;
  const pre = CONFIG.REG_PREFIX + '-' + y + '-';
  let max = 0;
  readAll_(T.VEH).forEach(v => {
    if (v.regNo.indexOf(pre) === 0) { const n = parseInt(v.regNo.slice(pre.length), 10); if (n > max) max = n; }
  });
  return pre + ('000' + (max + 1)).slice(-4);
}

function usernameTaken_(u) {
  const x = String(u).trim().toLowerCase();
  return readAll_(T.STU).some(s => s.username.toLowerCase() === x) ||
         readAll_(T.ADM).some(a => a.username.toLowerCase() === x);
}

/* ========================= UTILITIES ========================= */
function now_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss'); }
function uid_() { return Utilities.getUuid().replace(/-/g, '').slice(0, 10).toUpperCase(); }
function digits_(s) { return String(s || '').replace(/\D/g, ''); }
function normPlate_(s) { return String(s || '').replace(/[\s-]/g, '').toUpperCase(); }
function strip_(o) { const r = Object.assign({}, o); delete r.passwordHash; return r; }
function safe_(v) {
  if (v === undefined || v === null) return '';
  v = String(v).trim();
  return /^[=+@]/.test(v) ? "'" + v : v;
}
function hash_(s) {
  return Utilities.base64Encode(Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256, String(s) + '|' + CONFIG.SALT, Utilities.Charset.UTF_8));
}
function req_(p, keys) {
  keys.forEach(k => { if (p[k] === undefined || p[k] === null || String(p[k]).trim() === '') throw new Error('กรุณากรอกข้อมูลให้ครบถ้วน'); });
}
function checkUser_(u) { if (!/^[A-Za-z0-9_.]{4,30}$/.test(String(u).trim())) throw new Error('Username ต้องเป็นภาษาอังกฤษ/ตัวเลข 4-30 ตัวอักษร'); }
function checkPass_(p) { if (String(p).length < 6) throw new Error('Password ต้องมีอย่างน้อย 6 ตัวอักษร'); }
function checkPhone_(p) { if (!/^0\d{8,9}$/.test(digits_(p))) throw new Error('เบอร์โทรศัพท์ไม่ถูกต้อง'); }
function lock_(fn) {
  const l = LockService.getScriptLock();
  l.waitLock(20000);
  try { return fn(); } finally { l.releaseLock(); }
}
function log_(user, role, action, detail) {
  try { insert_(T.LOG, { time: now_(), user, role, action, detail: detail || '' }); } catch (e) {}
}

/* ---------- Session ---------- */
function newSession_(u) {
  const tk = Utilities.getUuid();
  CacheService.getScriptCache().put('S_' + tk, JSON.stringify(u), CONFIG.SESSION_SECONDS);
  return tk;
}
function sess_(p, role) {
  const c = CacheService.getScriptCache();
  const raw = p.token && c.get('S_' + p.token);
  if (!raw) throw new Error('SESSION_EXPIRED');
  const u = JSON.parse(raw);
  if (role && u.role !== role) throw new Error('คุณไม่มีสิทธิ์ใช้งานส่วนนี้');
  c.put('S_' + p.token, raw, CONFIG.SESSION_SECONDS);
  return u;
}

/* ---------- Image Upload (Custom Folder Support) ---------- */
function folderIdFromConfig_() {
  const raw = String(CONFIG.UPLOAD_FOLDER_ID || '').trim();
  if (!raw) return '';
  const m = raw.match(/folders\/([-\w]{10,})/) || raw.match(/[?&]id=([-\w]{10,})/) || raw.match(/^([-\w]{10,})$/);
  if (!m) throw new Error('รูปแบบ UPLOAD_FOLDER_ID ไม่ถูกต้อง');
  return m[1];
}

function rootFolder_() {
  const id = folderIdFromConfig_();
  if (id) {
    try {
      const f = DriveApp.getFolderById(id);
      f.getName();
      return f;
    } catch (e) {
      throw new Error('ไม่สามารถเข้าถึงโฟลเดอร์เก็บรูปได้ กรุณาตรวจสอบ UPLOAD_FOLDER_ID และสิทธิ์การเข้าถึง');
    }
  }
  const pr = PropertiesService.getScriptProperties();
  const autoId = pr.getProperty('FOLDER_ID');
  if (autoId) { try { return DriveApp.getFolderById(autoId); } catch (e) {} }
  const f = DriveApp.createFolder(CONFIG.UPLOAD_FOLDER);
  pr.setProperty('FOLDER_ID', f.getId());
  return f;
}

function folder_(sub) {
  const root = rootFolder_();
  if (!sub || !CONFIG.USE_SUB_FOLDERS) return root;
  const it = root.getFoldersByName(sub);
  return it.hasNext() ? it.next() : root.createFolder(sub);
}

function saveImage_(dataUrl, name, sub) {
  if (!dataUrl || String(dataUrl).indexOf('base64,') < 0) return '';
  if (String(dataUrl).length > 7000000) throw new Error('ไฟล์ภาพมีขนาดใหญ่เกินไป กรุณาเลือกรูปที่มีขนาดเล็กลง');
  const parts = String(dataUrl).split('base64,');
  const mime = (parts[0].match(/data:(.*?);/) || [])[1] || 'image/jpeg';
  if (mime.indexOf('image/') !== 0) throw new Error('รองรับเฉพาะไฟล์รูปภาพ');
  const ext = mime === 'image/png' ? '.png' : (mime === 'image/webp' ? '.webp' : '.jpg');
  const blob = Utilities.newBlob(Utilities.base64Decode(parts[1]), mime, name + '_' + Date.now() + ext);
  const file = folder_(sub).createFile(blob);
  try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return 'https://lh3.googleusercontent.com/d/' + file.getId();
}

function testFolder() {
  const f = rootFolder_();
  Logger.log('โฟลเดอร์หลัก : ' + f.getName());
  Logger.log('URL โฟลเดอร์ : ' + f.getUrl());
  if (CONFIG.USE_SUB_FOLDERS) ['รูปนักเรียน', 'รูปรถ'].forEach(s => Logger.log('โฟลเดอร์ย่อย : ' + folder_(s).getName()));
}

/* ---------- หน้าตรวจสอบจาก QR Code ---------- */
function escHtml_(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function renderVerify_(regNo) {
  const e = escHtml_;
  const v = readAll_(T.VEH).find(x => x.regNo === String(regNo).trim());
  const vc = v ? readAll_(T.VIO).filter(x => x.vehicleId === v.id).length : 0;
  const color = !v ? '#e53935' : v.status === ST.ACTIVE ? '#2e7d32' : '#f9a825';
  const row = (k, val) => `<tr><th>${k}</th><td>${e(val)}</td></tr>`;
  const body = !v
    ? `<div class="st" style="background:#e53935">ไม่พบข้อมูลทะเบียนนี้ในระบบ</div><p>${e(regNo)}</p>`
    : `${v.photoUrl ? `<img src="${e(v.photoUrl)}" class="ph">` : ''}
       <div class="reg">${e(v.regNo)}</div>
       <div class="st" style="background:${color}">สถานะ : ${e(v.status)}</div>
       <table>${row('ชื่อ-สกุล', v.studentName)}${row('ระดับชั้น', v.classLevel)}
       ${row('ทะเบียนรถ', v.plate + ' ' + v.province)}${row('ยี่ห้อ/รุ่น', v.brand + ' ' + v.model)}
       ${row('สี', v.color)}${row('ประวัติกระทำผิด', vc + ' ครั้ง')}</table>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Google+Sans+Flex:GRAD,opsz,ROND,wdth,wght@0..100,6..144,0..100,25..151,1..1000&display=swap" rel="stylesheet">
  <style>body{font-family:'Google Sans Flex',sans-serif;background:#eaf3ff;margin:0;padding:16px}
  .box{max-width:420px;margin:auto;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 10px 30px rgba(13,71,161,.2);text-align:center}
  .hd{background:linear-gradient(120deg,#062a6b,#1976d2);color:#fff;padding:18px;font-weight:600}
  .ph{width:100%;max-height:240px;object-fit:cover}.reg{font-size:1.6rem;font-weight:600;color:#0b3d91;margin:12px}
  .st{color:#fff;margin:0 16px;padding:10px;border-radius:10px;font-weight:600}
  table{width:calc(100% - 32px);margin:16px;border-collapse:collapse;text-align:left}
  th,td{padding:8px;border-bottom:1px solid #e3f0ff}th{color:#5c6f87;font-weight:400;width:40%}
  .ts{color:#888;font-size:.8rem,padding-bottom:14px}</style></head>
  <body><div class="box"><div class="hd">${e(CONFIG.SCHOOL_NAME)}<br><small>ตรวจสอบทะเบียนรถจักรยานยนต์นักเรียน</small></div>
  ${body}<p class="ts">ตรวจสอบเมื่อ ${now_()}</p></div></body></html>`;
}